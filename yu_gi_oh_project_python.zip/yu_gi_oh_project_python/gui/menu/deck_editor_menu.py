import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk

    #make each frame with two parts:
    # label frame with has the name of the deck, the monster, spell, trap count
    #all the cards in the deck



class DeckEditorMenu(ttk.Frame):
    def __init__(self, parent) -> None:
        """_summary_

        Args:
            parent (tk.Frame): Parent is the main menu ttk.Frame
        """
        super().__init__(parent)
        self.create_widgets()
        self.create_layout()

    def create_widgets(self):
        self.left_menu_frame = LeftSideMenu(self, command=self.back_to_main_menu) 
        self.middle_deck_frame = DecksMenu(self, {}) 
        self.right_search_frame = RightSideMenu(self)

    def create_layout(self):
        self.left_menu_frame.pack(side='left', expand=True, fill='both')
        self.middle_deck_frame.pack(side='left', expand=True, fill='both')
        self.right_search_frame.pack(side='left', expand=True, fill='both')

    def back_to_main_menu(self):
        """Method to go back to the main menu."""
        self.master.create_main_menu()
    


class DisplaySingleDeck(ttk.Frame):
    def __init__(self, parent, deck_id_list:list, deck_type: str, grid_dimensions: tuple, card_dimensions: tuple) -> None:
        """Initializes the DeckDisplay frame.
        
        Args:
            parent (ttk.Frame): Parent is the DeckEditorMenu tk.Frame
            deck_type (str): 'Main', 'Side', 'Extra'
            grid_dimensions (tuple): (number_of_rows, number_of_cols)
            card_dimensions (tuple): (width, height) in pixels
        """
        super().__init__(parent)
        
        self.deck_id_list = deck_id_list
        self.deck_type = deck_type
        self.grid_dimensions = grid_dimensions
        self.card_dimensions = card_dimensions
        self.deck_buttons = []
        self.create_widgets()        
        self.create_layout()        

    def create_widgets(self):
        
        self.label_frame = tk.Frame(master=self,borderwidth = 1, relief="solid")
        self.deck_label = ttk.Label(self.label_frame,text = self.deck_type)

        self.deck_frame = tk.Frame(master=self,borderwidth = 1, relief="solid")

        number_empty_buttons = self.grid_dimensions[0] * self.grid_dimensions[1]
        for index in range(number_empty_buttons):
            canvas = tk.Canvas(master=self.deck_frame,
                               width=self.card_dimensions[0],
                               height=self.card_dimensions[1],
                              )
            
            canvas.create_rectangle(0, 0, self.card_dimensions[0] - 1, self.card_dimensions[1] - 1,
                                    outline='#32fbe2', width=1)
            
            self.deck_buttons.append(canvas) 
            row = index // self.grid_dimensions[1]
            col = index % self.grid_dimensions[1]
            canvas.grid(row=row, column=col, sticky="nsew", padx=1, pady=1)

    def create_layout(self):
        self.label_frame.pack()
        self.deck_label.pack()
        self.deck_frame.pack()       
        for index in range(self.grid_dimensions[1]): 
            self.deck_frame.columnconfigure(index, weight=1)

        for index in range(self.grid_dimensions[0]):
            self.deck_frame.rowconfigure(index, weight=1)

    def display_deck(self):
        self.deck_images = []
        for index, card_id in enumerate(self.deck_id_list):
            img = self.load_card_image(card_id, self.card_dimensions)
            if img:
                self.deck_images.append(img)
                self.deck_buttons[index].configure(image=img)

    def load_card_image(self, card_id, size: tuple) -> ImageTk.PhotoImage:
        """Load and resize card images for the deck sections."""
        try:
            img_path = f"./assets/cards_images/{card_id}.svg"
            img = Image.open(img_path).resize(size)
            return ImageTk.PhotoImage(img)
        except FileNotFoundError:
            print(f"Image for card ID {card_id} not found.")
            return None


class DecksMenu(ttk.Frame):

    def __init__(self, parent, deck_dict: dict) -> None:
        """_summary_

        Args:
            parent (_type_): _description_
            deck_dict (dict): _description_
        """
        super().__init__(parent)
        self.deck_dict = deck_dict
        self.create_widgets()
        self.create_layout()

    def create_widgets(self):
        
        main_deck_card_size = (72, 105)
        side_extra_card_size = (49, 71)
        
        main_deck_col_row = (6, 10)
        side_extra_deck_col_row = (1, 15)

        #Todo - real card_id list from the fixed card data factory
        empty_id_list = []
        self.main_deck_frame = DisplaySingleDeck(self,empty_id_list, 'Main', main_deck_col_row, main_deck_card_size)
        self.side_deck_frame = DisplaySingleDeck(self,empty_id_list, 'Side', side_extra_deck_col_row, side_extra_card_size)
        self.extra_deck_frame = DisplaySingleDeck(self,empty_id_list, 'Extra', side_extra_deck_col_row, side_extra_card_size)

    def create_layout(self):
        self.main_deck_frame.pack(fill='both', expand=True)
        self.side_deck_frame.pack(fill='both', expand=True)
        self.extra_deck_frame.pack(fill='both', expand=True)

class LeftSideMenu(ttk.Frame): 
    def __init__(self, parent, command=None, load_deck_command=None) -> None: 
        super().__init__(parent) 
        self.back_command = command 
        self.load_deck_command = load_deck_command 
        self.create_widgets() 
        self.create_layout() 
    
    def create_widgets(self): 
        self.card_preview_frame = ttk.Frame(self, borderwidth=2, relief="solid") 
        self.card_preview_canvas = tk.Canvas(self.card_preview_frame) 
        self.card_description = tk.Text(self.card_preview_frame) 
        self.bottom_menu_frame = ttk.Frame(self, borderwidth=2, relief="solid") 
        self.open_deck_button = ttk.Button(self.bottom_menu_frame, bootstyle="outline", text='Open Deck', command=self.load_deck_command) 
        self.export_deck_button = ttk.Button(self.bottom_menu_frame, bootstyle="outline", text='Export Deck', command=self.export_deck) 
        self.clear_deck_button = ttk.Button(self.bottom_menu_frame, bootstyle="outline", text='Clear Deck', command=self.clear_deck) 
        self.set_as_default_deck_button = ttk.Button(self.bottom_menu_frame, bootstyle="outline", text='Set As Default', command=self.set_as_default) 
        self.new_deck_button = ttk.Button(self.bottom_menu_frame, bootstyle="outline", text='New Deck', command=self.new_deck) 
        self.rename_deck_button = ttk.Button(self.bottom_menu_frame, bootstyle="outline", text='Rename Deck', command=self.rename_deck) 
        self.delete_deck_button = ttk.Button(self.bottom_menu_frame, bootstyle="outline", text='Delete Deck', command=self.delete_deck) 
        self.save_deck_button = ttk.Button(self.bottom_menu_frame, bootstyle="outline", text='Save Deck', command=self.save_deck) 
        self.save_as_deck_button = ttk.Button(self.bottom_menu_frame, bootstyle="outline", text='Save Deck As', command=self.save_as_deck) 
        self.to_main_menu_button = ttk.Button(self.bottom_menu_frame, bootstyle="outline", text='Back to Main Menu', command=self.back_command) 
        self.decks_combobox = ttk.Combobox(self.bottom_menu_frame) 
    
    def create_layout(self): 
        self.card_preview_frame.pack(pady=5) 
        self.bottom_menu_frame.pack(pady=5) 
        self.bottom_menu_frame.columnconfigure((0, 1), weight=1, uniform='a') 
        self.decks_combobox.grid(row=0, column=0, columnspan=2, padx=5, pady=5, sticky="nsew") 
        self.open_deck_button.grid(row=1, column=0, padx=5, pady=5, sticky="nsew") 
        self.export_deck_button.grid(row=1, column=1, padx=5, pady=5, sticky="nsew") 
        self.clear_deck_button.grid(row=2, column=0, padx=5, pady=5, sticky="nsew") 
        self.set_as_default_deck_button.grid(row=2, column=1, padx=5, pady=5, sticky="nsew") 
        self.new_deck_button.grid(row=3, column=0, padx=5, pady=5, sticky="nsew") 
        self.rename_deck_button.grid(row=3, column=1, padx=5, pady=5, sticky="nsew") 
        self.delete_deck_button.grid(row=4, column=0, padx=5, pady=5, sticky="nsew") 
        self.save_deck_button.grid(row=4, column=1, padx=5, pady=5, sticky="nsew") 
        self.save_as_deck_button.grid(row=5, column=0, padx=5, pady=5, sticky="nsew") 
        self.to_main_menu_button.grid(row=5, column=1, padx=5, pady=5, sticky="nsew") 
   
    def load_deck(self): 
        print("Load deck button clicked") 
    def export_deck(self):  
        print("Export deck button clicked") 
    def clear_deck(self): 
        print("Clear deck button clicked") 
    def set_as_default(self): 
        print("Set as default deck button clicked") 
    def new_deck(self): 
        print("New deck button clicked") 
    def rename_deck(self): 
        print("Rename deck button clicked") 
    def delete_deck(self): 
        print("Delete deck button clicked") 
    def save_deck(self): 
        print("Save deck button clicked") 
    def save_as_deck(self): 
        print("Save deck as button clicked")

class RightSideMenu(ttk.Frame):
    def __init__(self, parent) -> None:
        super().__init__(parent)
        self.create_widgets()
        self.create_layout()

    def create_widgets(self):
        self.search_frame = ttk.Frame(self, borderwidth=2, relief="solid")
        self.name_label_search_entry = ttk.Label(self.search_frame, text='Name:')
        self.card_name_entry = ttk.Entry(self.search_frame)
        self.card_label = ttk.Label(self.search_frame, text='Card:')
        self.card_desc_entry = ttk.Entry(self.search_frame)
        self.search_button = ttk.Button(self.search_frame,bootstyle="outline", text='Search')
        self.type_label = ttk.Label(self.search_frame, text='Type:')
        self.atribute_label = ttk.Label(self.search_frame, text='Atrribute:')

    def create_layout(self):
        self.search_frame.pack()
        self.search_frame.columnconfigure((0,1),weight = 1)
        self.name_label_search_entry.grid(row=0, column = 0,padx=5, pady=5, sticky="nsew")
        self.card_name_entry.grid(row=0, column = 1, padx=5, pady=5, sticky="nsew")
        self.card_label.grid(row=1, column = 0, padx=5, pady=5, sticky="nsew")
        self.card_desc_entry.grid(row=1, column = 1, padx=5, pady=5, sticky="nsew")
        self.type_label.grid(row=2, column = 0, padx=5, pady=5, sticky="nsew")
        self.atribute_label.grid(row=3, column = 0, padx=5, pady=5, sticky="nsew")
        
        self.search_button.grid(row=4, column = 0, columnspan = 2, padx=5, pady=5, sticky="nsew")

