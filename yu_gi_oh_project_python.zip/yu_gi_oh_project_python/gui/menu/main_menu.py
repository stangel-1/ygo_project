import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import ttkbootstrap as ttk
from PIL import Image, ImageTk
import sys

sys.path.append('F:/Projects/YGO_PROJECT/yu_gi_oh_project_python/')
from deck_editor_menu import DeckEditorMenu
class App(ttk.Window):
    def __init__(self):
        super().__init__()
        #ttk.Style('vapor')
       
        self.create_main_menu()

    def create_main_menu(self):
        """Create the main menu with buttons for each section."""
        self.clear_window()
        
        self.button_frame = ttk.Frame(self)
        # Main Menu Buttons
        button1 = ttk.Button(self.button_frame, text="Duel", command=self.open_single_player)
        button2 = ttk.Button(self.button_frame, text="Test", command=self.open_test_mode)
        button3 = ttk.Button(self.button_frame, text="Deck Editor", command=self.open_deck_editor)
        button4 = ttk.Button(self.button_frame, text="Exit", command=self.quit)

        button1.pack(side='top', expand=True, fill='both', padx=2, pady=2)
        button2.pack(side='top', expand=True, fill='both', padx=2, pady=2)
        button3.pack(side='top', expand=True, fill='both', padx=2, pady=2)
        button4.pack(side='top', expand=True, fill='both', padx=2, pady=2)

        self.button_frame.place(relx=0.5, rely=0.5, anchor="center")

    def clear_window(self):
        """Clear all widgets in the current window."""
        for widget in self.winfo_children():
            widget.destroy()

    def open_single_player(self):
        """Open the Single Player page."""
        self.clear_window()
        label = ttk.Label(self, text="Single Player Mode", font=("Arial", 20))
        label.pack(pady=20)

        start_game_button = ttk.Button(self, text="Start Game", width=20, height=2, command=self.start_ai_game)
        start_game_button.pack(pady=10)

        back_button = ttk.Button(self, text="Back to Main Menu", width=20, height=2, command=self.create_main_menu)
        back_button.pack(pady=10)


    def open_test_mode(self):

        self.clear_window()
        label = ttk.Label(self, text="Test Mode", font=("Arial", 20))
        label.pack(pady=20)

        message = ttk.Label(self, text="Coming soon!", font=("Arial", 14))
        message.pack(pady=10)

        back_button = ttk.Button(self, text="Back to Main Menu", width=20, height=2, command=self.create_main_menu)
        back_button.pack(pady=10)

    def open_deck_editor(self):
        """Open the Deck Editor."""
        self.clear_window()
        deck_editor = DeckEditorMenu(self)
        deck_editor.pack(fill="both", expand=True)

    def open_deck(self):
        """Open a selected deck."""
        selected_deck = self.current_deck  
        messagebox.showinfo("Open Deck", f"Opening deck: {selected_deck}")

    def back_to_main_menu(self):
        """Return to the main menu."""
        self.create_main_menu()




if __name__ == "__main__":
    app = App()
    app.mainloop()
