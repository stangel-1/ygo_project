TODO
1. The replay_reader should accept a link to Duelingbook.com replay
2. 