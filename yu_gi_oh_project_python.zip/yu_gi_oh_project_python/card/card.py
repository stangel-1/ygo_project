from abc import ABC, abstractmethod
from card.card_database import Database

class Card(ABC):
    def __init__(self, id, name, race, card_type, desc):
        self.id = id
        self.name = name
        self.race = race
        self.card_type = card_type
        self.desc = desc

    def get_id(self):
        return self.id

    def get_name(self):
        return self.name

    def get_card_type(self):
        return self.card_type

    @abstractmethod
    def __str__(self):
        pass

class MonsterCard(Card):
    def __init__(self, id, name, race, card_type, desc, atk, deff, level, attribute):
        super().__init__(id, name, race, card_type, desc)
        self.atk = atk
        self.deff = deff
        self.level = level   
        self.attribute = attribute

    def __str__(self):
        return f"MonsterCard(name={self.name}, race={self.race}, atk={self.atk}, def={self.deff}, level={self.level})"

class SpellCard(Card):
    def __init__(self, id, name, race, card_type, desc):
        super().__init__(id, name, race, card_type, desc)
    
    def __str__(self):
        return f"SpellCard(name={self.name}, race={self.race}, type={self.card_type})"
    
class TrapCard(Card):
    def __init__(self, id, name, race, card_type, desc):
        super().__init__(id, name, race, card_type, desc)

    def __str__(self):
        return f"TrapCard(name={self.name}, race={self.race}, type={self.card_type})"

class CardFactory:
    def __init__(self):
        self.database_dict = Database().read_cardpool()

    def create_card(self, card_id):
        for each in self.database_dict.get('data'):
            curr_id = each.get('id')
            if card_id == str(curr_id):
                name = each.get('name')
                race = each.get('race')
                card_type = each.get('type')
                desc = each.get('desc')

                if "Monster" in card_type:
                    atk = each.get('atk')
                    deff = each.get('def')
                    level = each.get('level')
                    attribute = each.get('attribute')
                    return MonsterCard(card_id, name, race, card_type, desc, atk, deff, level, attribute)
                
                elif "Spell" in card_type:
                    return SpellCard(card_id, name, race, card_type, desc)
                
                elif "Trap" in card_type:
                    return TrapCard(card_id, name, race, card_type, desc)

        raise ValueError(f"No card with id: {card_id}")
