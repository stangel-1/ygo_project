import os
import random
from abc import ABC, abstractmethod
from card.card import CardFactory

class Deck(ABC):
    def __init__(self):
        self.cards = []

    def sort_decklist_alphabetically(self):
        monsters, spells, traps = [], [], []
        for card in self.cards:
            card_type = card.get_card_type()
            if 'Monster' in card_type:
                monsters.append(card)
            elif 'Spell' in card_type:
                spells.append(card)
            elif 'Trap' in card_type:
                traps.append(card)

        monsters.sort(key=lambda card: card.get_name())
        spells.sort(key=lambda card: card.get_name())
        traps.sort(key=lambda card: card.get_name())

        self.cards = monsters + spells + traps

    def shuffle(self):
        random.shuffle(self.cards)

    @abstractmethod
    def validate_deck(self):
        pass

    def write_deck_to_txt(self, outfile):
        card_count_dict = {}
        for card in self.cards:
            card_name = card.get_name()
            card_count_dict[card_name] = card_count_dict.get(card_name, 0) + 1

        for index, (card_name, count) in enumerate(card_count_dict.items()):
            outfile.write(f"{count}x {card_name}\n" if index < len(card_count_dict) - 1 else f"{count}x {card_name}")

    def return_card_id_list(self):
        return [card.get_id() for card in self.cards]

    def print_deck(self):
        if not self.cards:
            print("The deck is empty.")
        else:
            print("Deck cards:")
            for card in self.cards:
                print(f"{card.get_name()}")

class MainDeck(Deck):
    def __init__(self, card_id_list, card_factory):
        super().__init__()
        self.cards = [card_factory.create_card(card_id) for card_id in card_id_list]

    def validate_deck(self):
        if len(self.cards) < 40:
            raise ValueError("Main Deck must have at least 40 cards.")
        if len(self.cards) > 60:
            raise ValueError("Main Deck cannot have more than 60 cards.")

class SideDeck(Deck):
    def __init__(self, card_id_list, card_factory):
        super().__init__()
        self.cards = [card_factory.create_card(card_id) for card_id in card_id_list]

    def validate_deck(self):
        if len(self.cards) > 15:
            raise ValueError("Side Deck must be a maximum of 15 cards.")

class ExtraDeck(Deck):
    def __init__(self, card_id_list, card_factory):
        super().__init__()
        self.cards = [card_factory.create_card(card_id) for card_id in card_id_list]

    def validate_deck(self):
        if any(card.get_card_type() != 'Fusion Monster' for card in self.cards):
            raise ValueError("Card type of Extra Deck must be 'Fusion Monster'.")

class DeckFactory:
    @staticmethod
    def create_main_deck(card_ids, card_factory):
        return MainDeck(card_ids, card_factory)

    @staticmethod
    def create_side_deck(card_ids, card_factory):
        return SideDeck(card_ids, card_factory)

    @staticmethod
    def create_extra_deck(card_ids, card_factory):
        return ExtraDeck(card_ids, card_factory)

    @staticmethod
    def create_deck(filename):
        deck_dict = DeckFactory.open_ydk_to_dict(filename)
        card_factory = CardFactory()
        main_deck = DeckFactory.create_main_deck(deck_dict['Main'], card_factory)
        side_deck = DeckFactory.create_side_deck(deck_dict['Side'], card_factory)
        extra_deck = DeckFactory.create_extra_deck(deck_dict['Extra'], card_factory)
        return main_deck, side_deck, extra_deck

    @staticmethod
    def open_ydk_to_dict(filename) -> dict:
        directory = "./assets/deck_files/"
        file_path = os.path.join(directory, filename)
        deck_dict = {'Main': [], 'Side': [], 'Extra': []}

        try:
            with open(file_path, "r") as file:
                lines = [line.strip() for line in file if line.strip()]

            main_start = lines.index('#main') + 1 if '#main' in lines else None
            extra_start = lines.index('#extra') + 1 if '#extra' in lines else None
            side_start = lines.index('!side') + 1 if '!side' in lines else None

            if main_start is None or extra_start is None or side_start is None:
                raise ValueError("Missing expected sections")

            deck_dict['Main'] = lines[main_start:extra_start - 1]
            deck_dict['Extra'] = lines[extra_start:side_start - 1]
            deck_dict['Side'] = lines[side_start:]

        except FileNotFoundError:
            print(f"Error: The file '{filename}' was not found in '{file_path}'.")
        except ValueError as e:
            print(f"Error: {e}")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")

        return deck_dict

class CompleteDeck:
    def __init__(self, filename) -> None:
        self.filename = filename
        self.main_deck, self.side_deck, self.extra_deck = DeckFactory.create_deck(filename)

    def write_complete_deck_to_txt(self):
        with open(f"{self.filename}.txt", "w") as outfile:
            outfile.write("Main Deck:\n")
            self.main_deck.write_deck_to_txt(outfile)
            outfile.write("\n\nSide Deck:\n")
            self.side_deck.write_deck_to_txt(outfile)
            outfile.write("\n\nExtra Deck:\n")
            self.extra_deck.write_deck_to_txt(outfile)

    def validate_complete_deck(self):
        self.main_deck.validate_deck()
        self.side_deck.validate_deck()
        self.extra_deck.validate_deck()

    def sort_complete_deck_alphabetically(self):
        self.main_deck.sort_decklist_alphabetically()
        self.side_deck.sort_decklist_alphabetically()
        self.extra_deck.sort_decklist_alphabetically()
