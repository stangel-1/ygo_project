import requests
import json
import os

FILENAME = "goat_format_cardpool.json"

class Database:
    @staticmethod
    def download_card_image(card_id, dict):
        try:
            for cards in dict.get('data'):
                if card_id == cards.get('id'):
                    url = cards.get('card_images')    
                    image_url = url[0]['image_url']
                    response = requests.get(image_url)
                    if response.status_code:
                        with open(f"{card_id}.png", 'wb') as fp:
                            fp.write(response.content)
        except requests.RequestException as req_error:
            print(f"Error during the request for card ID {card_id}: {req_error}")
        except IOError as io_error:
            print(f"Error writing image {card_id}: {io_error}")
        except Exception as e:
            print(f"An unexpected error occurred while downloading card ID {card_id}: {e}")

    @staticmethod
    def download_all_cards(dict):
        for each in dict.get('data'):
            curr_id = each.get('id')
            Database.download_card_image(curr_id, dict)

    @staticmethod
    def get_card_data_from_database(id):
        card_data_list = []
        database_dict = Database.read_cardpool()
        for card in database_dict.get('data'):
            if id == card.get('id'):
                card_data_list.append(card.get('name'))
                card_data_list.append(card.get('race'))
                card_data_list.append(card.get('type'))
                card_data_list.append(card.get('desc'))
        return card_data_list

    @staticmethod
    def load_cardpool():
        try:
            if not os.path.exists(FILENAME):
                SITE = "https://db.ygoprodeck.com/api/v7/cardinfo.php?format=goat"
                response = requests.get(SITE)
                response.raise_for_status()
                resp_dict = response.json()

                with open(FILENAME, "w") as outfile:
                    json.dump(resp_dict, outfile, indent=4, sort_keys=True)

                print(f"Card pool downloaded and saved to {FILENAME}.")
        except requests.RequestException as req_error:
            print(f"Error during requests to {SITE}: {req_error}")
        except json.JSONDecodeError as json_error:
            print(f"Error decoding JSON: {json_error}")
        except IOError as io_error:
            print(f"Error writing to file {FILENAME}: {io_error}")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")

    @staticmethod
    def read_cardpool():
        try:
            with open(FILENAME, "r") as outfile:
                resp_dict = json.load(outfile)
            return resp_dict
        except FileNotFoundError as fnf_error:
            print(f"Error: {fnf_error}")
            return {}
        except json.JSONDecodeError as json_error:
            print(f"JSON is invalid: {json_error}")
            return {}
        except IOError as io_error:
            print(f"Error reading file: {io_error}")
            return {}
        except Exception as e:
            print(f"An unexpected error occurred: {e}")
            return {}

    @staticmethod
    def isImageFolder():
        images_dir = './assets/cards_images'
        if not os.path.exists(images_dir):
            try:
                os.makedirs(images_dir)
            except OSError as e:
                print(f"Error creating directory: {e}")
                return
            
            json_file = Database.read_cardpool()
            Database.download_all_cards(json_file)
            print("Downloaded all card images.")
        else:
            print(f"Directory already exists: {images_dir}")
