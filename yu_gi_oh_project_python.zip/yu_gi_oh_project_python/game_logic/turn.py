from action import *

class Turn:
    def __init__(self) -> None:
        action_list = []
    def add_action(self)->None:
        """ Wait for an action until the Duel Finishing Action
        """
        completed = False
        while not completed:
            
            self.action_list.append(Action())