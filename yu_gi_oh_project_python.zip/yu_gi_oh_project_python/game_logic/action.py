from abc import abstractmethod, ABC

class Action(ABC):
    def __init__(self) -> None:
        super().__init__()

        """The main action class - all the other action classes
        should be child of this one
        REMOVE_ACTION class
        PlaceCardOnBoardAction
        draw_action and so on
        """
''' Various possible actions
def place_monster(self, monster, position):
        if 0 <= position < 5:
            if self.monster_row[position] is None:
                self.monster_row[position] = monster
                print(f"Placed monster {monster} at position {position}.")
            else:
                print(f"Position {position} is already occupied by {self.monster_row[position]}.")
        else:
            print("Invalid position! Choose a position between 0 and 4.")

    def place_spell_trap(self, spell_trap, position):
        if 0 <= position < 5:
            if self.spell_trap_row[position] is None:
                self.spell_trap_row[position] = spell_trap
                print(f"Placed spell/trap {spell_trap} at position {position}.")
            else:
                print(f"Position {position} is already occupied by {self.spell_trap_row[position]}.")
        else:
            print("Invalid position! Choose a position between 0 and 4.")

    def remove_monster(self, position):
        if 0 <= position < 5 and self.monster_row[position] is not None:
            removed_monster = self.monster_row[position]
            self.monster_row[position] = None
            print(f"Removed monster {removed_monster} from position {position}.")
        else:
            print("Invalid position or no monster to remove.")

    def remove_spell_trap(self, position):
'''