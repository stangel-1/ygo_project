from card.deck import CompleteDeck

class Player:
    def __init__(self,player_name: str, filename: str ,elo: int):
        """Creates instance of class Player

        Args:
            player_name (_type_): _description_
            filename (string): Deck filename ending in .ydk
            elo - this should be determined by an algorithm
        """
        self.player_name = player_name
        self.deck = CompleteDeck(filename)
        self.elo = elo
    #TDO implement getters/settters for player_name, deck, elo     
    