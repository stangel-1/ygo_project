from game_logic.player import Player
from game_logic.board import Board
from game_logic.turn import Turn
from card.deck import CompleteDeck

class Game:
    def __init__(self,player1: Player,player2: Player) -> None:
        self.player1 = player1
        self.player2 = player2
        self.board = Board()
        self.turns = [Turn]


    def game_loop(self):
        while True:
            self.turns.append()
            pass